'''
Created on 26 de out de 2017

@author: Luis Henrique Cantelli Reis
'''
from ssl import socket_error

class MyClass(object):
    '''
    classdocs
    '''
    

    def __init__(self, params):
        '''
        Constructor
        '''
        