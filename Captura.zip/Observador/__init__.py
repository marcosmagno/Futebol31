'''
Created on 26 de out de 2017

@author: Luis Henrique Cantelli Reis
'''
from Commons import comunica
