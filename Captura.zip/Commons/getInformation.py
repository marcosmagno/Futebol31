import cv2

print (cv2.getBuildInformation())
